AI-TTS local audio evidence

Contains the selected spoken content. Share only when you choose.
Each clips/ directory contains audio and synthesis/playback JSONL logs.
Times are Unix seconds; monotonic readings share a process_session.
Playback sessions identify replays. See manifest.json for missing evidence.
Generation-time versions live in generation.json, not export_runtime.
